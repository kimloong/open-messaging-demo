package io.openmessaging.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import io.openmessaging.KeyValue;
import io.openmessaging.Message;
import io.openmessaging.Producer;
import io.openmessaging.demo.DefaultKeyValue;
import io.openmessaging.demo.DefaultProducer;

public class ProducerTest {

	public static void main(String[] args) {
		test();
	}

	private static AtomicInteger workIndex;
	private static TestMessageCreator testMsgCreator;
	private static Producer producer;

	public static void test() {
        KeyValue properties = new DefaultKeyValue();
        /*
        //实际测试时利用 STORE_PATH 传入存储路径
        //所有producer和consumer的STORE_PATH都是一样的，选手可以自由在该路径下创建文件
         */
        properties.put("STORE_PATH", TestParams.STORE_PATH);

        producer = new DefaultProducer(properties);
        workIndex = new AtomicInteger(0);
        testMsgCreator = new TestMessageCreator();

        ExecutorService executor = Executors.newFixedThreadPool(TestParams.PRODUCER_THREADS);

        long start = System.currentTimeMillis();
        boolean finished = false;

        for (int i = 0; i < TestParams.PRODUCER_THREADS; i++) {
        	executor.execute(worker);
        }
        executor.shutdown();
        try {
			finished = executor.awaitTermination(TestParams.WORKER_TIME_LIMIT, TimeUnit.SECONDS);
			producer.flush();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

        long end = System.currentTimeMillis();

        long elapsed = end - start;
        System.out.println("Message count " + TestParams.MSG_PER_TOPIC * (workIndex.get() - TestParams.PRODUCER_THREADS));
        System.out.println("finished " + finished);
        System.out.println("Producer cost " + elapsed + " ms");
        System.exit(0);
	}

	private static final Runnable worker = () -> {
    	while (true) {
        	int workCount = workIndex.getAndIncrement();
        	if (workCount < TestParams.TOPIC_COUNT) {
        		String topic = "TOPIC" + workCount;

//        		System.out.println("creating message for topic " + topic);
        		for (int i = 0; i < TestParams.MSG_PER_TOPIC; i++) {
        			Message msg = testMsgCreator.createMessageToTopic(topic, i);
        			producer.send(msg);
        		}
        	} else if (workCount < TestParams.WORK_COUNT) {
        		String queue = "QUEUE" + (workCount - TestParams.TOPIC_COUNT);

//        		System.out.println("creating message for queue " + queue);
        		for (int i = 0; i < TestParams.MSG_PER_TOPIC; i++) {
        			Message msg = testMsgCreator.createMessageToQueue(queue, i);
        			producer.send(msg);
        		}
        	} else {
        		return; // we're done
        	}
    	}
    };
}
