package io.openmessaging.test;

public class TestUtils {
	public static byte[][] buildBodiesFromTemplate(byte[] template) {
		byte[][] bodies = new byte[][]{
			new byte[TestParams.BODY_SIZE[0]],
			new byte[TestParams.BODY_SIZE[1]],
			new byte[TestParams.BODY_SIZE[2]],
			new byte[TestParams.BODY_SIZE[3]]
		};
		
		for (byte[] body : bodies) {
			int pos = 0, len = template.length;
			int bodyLen = body.length;
			
			// body 就是重复 template 的内容
			while (pos < bodyLen) {
				len = Math.min(bodyLen - pos, len);
				System.arraycopy(template, 0, body, pos, len);
				pos += len;
			}
		}
		return bodies;
	}
}
