package io.openmessaging.test;

public class TestParams {
	public static final String STORE_PATH = "/root/open-messaging/temp/";
	
	public static final int BODY_TYPES = 4;
	public static final int[] BODY_SIZE = {
		512,
		16,
		64,
		32
	};
	
	public static final int TEMPLATE_LENGTH = 64;

	public static final String PROPERTIES_STR = "PROPS";
	
	public static int TOPIC_COUNT = 90;
	public static int QUEUE_COUNT = 10;
	public static int WORK_COUNT = TOPIC_COUNT + QUEUE_COUNT;
	
	public static int MSG_PER_TOPIC = 400000;
	
	public static int PRODUCER_THREADS = 10;
	public static int CONSUMER_THREADS = 10;
	
	public static int WORKER_TIME_LIMIT = 500; 
}
