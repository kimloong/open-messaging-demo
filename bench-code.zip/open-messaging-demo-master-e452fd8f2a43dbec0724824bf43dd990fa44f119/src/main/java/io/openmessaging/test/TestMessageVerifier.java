package io.openmessaging.test;

import java.util.Arrays;

import io.openmessaging.KeyValue;
import io.openmessaging.Message;
import io.openmessaging.MessageHeader;
import io.openmessaging.demo.DefaultBytesMessage;

public class TestMessageVerifier {
	private byte[] template;
	private byte[][] bodies;

	public TestMessageVerifier() {
	}

	public synchronized void init(byte[] body) {
		if (this.template == null) {
			template = Arrays.copyOf(body, TestParams.TEMPLATE_LENGTH);
			bodies = TestUtils.buildBodiesFromTemplate(template);
		}
	}

	public boolean verify(DefaultBytesMessage msg, int seq) {
		try {
			boolean passed = true;

			KeyValue headers = msg.headers();
			KeyValue properties = msg.properties();

			String seqStr = String.valueOf(seq);
			String msgSeq = headers.getString(MessageHeader.MESSAGE_ID);
			if (!seqStr.equals(msgSeq)) {
				System.out.println("seq fail");
				return false;
			}

			// headers & props
			int remainder = seq % 4;
			switch (remainder) {
			case 0:
				long timestamp = headers.getLong(MessageHeader.BORN_TIMESTAMP);
				passed = passed
						&& (1 == headers.getInt(MessageHeader.PRIORITY))
						&& (seqStr.equals(headers.getString(MessageHeader.TRACE_ID)))
						&& (timestamp == headers.getLong(MessageHeader.START_TIME))
						&& ("localhost".equals(headers.getString(MessageHeader.BORN_HOST)))
						&& (1000 == headers.getInt(MessageHeader.TIMEOUT))
						&& (1000 == headers.getInt(MessageHeader.RELIABILITY))
						&& (seqStr.equals(headers.getString(MessageHeader.SHARDING_KEY)))
						;
				break;
			case 1:
				passed = passed
						&& (TestParams.PROPERTIES_STR.equals(properties.getString("str")))
						&& (seq == properties.getInt("seq"))
						&& (seq == properties.getDouble("seqd"))
						&& (seq == properties.getLong("seql"))
						&& ("I_AM_A_VERY_LONG_PROPERTIES_VALUE__BITE_ME".equals(properties.getString("I_AM_A_VERY_LONG_PROPERTIES_KEY_SO_WHAT")));
				break;
			default: // case 2, 3
				break;
			}

			if (!passed) {
				System.out.println("header/props fail");
				return false;
			}

			// body
			byte[] body = msg.getBody();
			if (this.template == null || this.bodies == null) {
				this.init(body);
			}
			if (Arrays.equals(this.bodies[remainder], body)) {
				return true;
			} else {
				System.out.println("array compare fail");
				return false;
			}
		} catch (Throwable e) {
			e.printStackTrace();
			System.out.println("weird fail");
			return false;
		}
	}
}
