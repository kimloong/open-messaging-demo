package io.openmessaging.test;

import java.util.Arrays;
import java.util.Random;

import io.openmessaging.Message;
import io.openmessaging.MessageHeader;
import io.openmessaging.demo.DefaultMessageFactory;

public class TestMessageCreator {
	private DefaultMessageFactory messageFactory = new DefaultMessageFactory();
	private byte[][] bodies;

	public TestMessageCreator() {
		byte[] template = new byte[TestParams.TEMPLATE_LENGTH];
		Random rand = new Random();
		rand.nextBytes(template);
		this.bodies = TestUtils.buildBodiesFromTemplate(template);
	}

	public Message createMessageToTopic(String topic, int seq) {
		byte[] body = Arrays.copyOf(bodies[seq % 4], bodies[seq % 4].length);
		Message msg = messageFactory.createBytesMessageToTopic(topic, body);
		return fillHeadersAndProperties(msg, seq);
	}

	public Message createMessageToQueue(String queue, int seq) {
		byte[] body = Arrays.copyOf(bodies[seq % 4], bodies[seq % 4].length);
		Message msg = messageFactory.createBytesMessageToQueue(queue, body);
		return fillHeadersAndProperties(msg, seq);
	}

	public Message fillHeadersAndProperties(Message msg, int seq) {
		String seqStr = String.valueOf(seq);
		msg.putHeaders(MessageHeader.MESSAGE_ID, seqStr);
		int remainder = seq % 4;
		switch(remainder) {
		case 0:
			long timestamp = System.currentTimeMillis();
			msg.putHeaders(MessageHeader.PRIORITY, 1);
			msg.putHeaders(MessageHeader.TRACE_ID, seqStr);

			msg.putHeaders(MessageHeader.BORN_TIMESTAMP, timestamp);
			msg.putHeaders(MessageHeader.BORN_HOST, "localhost");
			msg.putHeaders(MessageHeader.START_TIME, timestamp);
			msg.putHeaders(MessageHeader.TIMEOUT, 1000);
			msg.putHeaders(MessageHeader.RELIABILITY, 1000);
			msg.putHeaders(MessageHeader.SHARDING_KEY, seqStr);
			break;
		case 1:
			msg.putProperties("str", TestParams.PROPERTIES_STR);
			msg.putProperties("seq", seq);
			msg.putProperties("seql", (long) seq);
			msg.putProperties("seqd", (double) seq);
			msg.putProperties("I_AM_A_VERY_LONG_PROPERTIES_KEY_SO_WHAT", "I_AM_A_VERY_LONG_PROPERTIES_VALUE__BITE_ME");
			break;
		default: // case 2, 3
			break;
		}
		return msg;
	}
}
