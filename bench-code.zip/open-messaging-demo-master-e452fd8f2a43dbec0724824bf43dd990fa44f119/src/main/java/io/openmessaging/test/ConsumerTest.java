package io.openmessaging.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

import io.openmessaging.KeyValue;
import io.openmessaging.MessageHeader;
import io.openmessaging.demo.DefaultBytesMessage;
import io.openmessaging.demo.DefaultKeyValue;
import io.openmessaging.demo.DefaultPullConsumer;

public class ConsumerTest {
	public static void main(String[] args) {
		test();
	}
	
	private static AtomicInteger queueIndex;
	private static KeyValue properties;
	private static int[] topics;
	private static LongAdder msgCount;
	private static TestMessageVerifier verifier;
	private static LongAdder failCount;
	
	public static void test() {
        properties = new DefaultKeyValue();
        properties.put("STORE_PATH", TestParams.STORE_PATH);
        
        topics = new int[TestParams.TOPIC_COUNT];
        for (int i = 0; i < TestParams.TOPIC_COUNT; i++) {
        	topics[i] = i;
        }
        
        //shuffle it
        Random rand = new Random();
        for (int i = 0; i < TestParams.TOPIC_COUNT; i++) {
        	int j = rand.nextInt(TestParams.TOPIC_COUNT);
        	int temp = topics[i];
        	topics[i] = topics[j];
        	topics[j] = temp;
        }
        
        queueIndex = new AtomicInteger();
        msgCount = new LongAdder();
        verifier = new TestMessageVerifier();
        failCount = new LongAdder();
        
        ExecutorService executor = Executors.newFixedThreadPool(TestParams.CONSUMER_THREADS);
        long start = System.currentTimeMillis();
        boolean finished = false;
        for (int i = 0; i < TestParams.CONSUMER_THREADS; i++) {
        	executor.execute(worker);
        }
        executor.shutdown();
        try {
			finished = executor.awaitTermination(TestParams.WORKER_TIME_LIMIT, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        long end = System.currentTimeMillis();
        long elapsed = end - start;
        System.out.println("Message count " + msgCount);
        System.out.println("fail count " + failCount);
        System.out.println("finished " + finished);
        System.out.println("Consumer cost " + elapsed + " ms");
        System.exit(0);
	}
	
	private static final Runnable worker = () -> {
		DefaultPullConsumer consumer = new DefaultPullConsumer(properties);
		int index = queueIndex.getAndIncrement();
		String queue = "QUEUE" + index;
		ArrayList<String> topicList = new ArrayList<>();
		for (int i = 0; i < 9; i++) {
			if (index * 9 + i > topics.length) {
				break;
			}
			topicList.add("TOPIC" + topics[index * 9 + i]);		
		}
		
		consumer.attachQueue(queue, topicList);
		System.out.println(queue + " attach topics: " + String.join(",", topicList));
		
		HashMap<String, Integer> seqMap = new HashMap<>();
		Integer zero = 0;
		
		while (true) {
			DefaultBytesMessage msg = (DefaultBytesMessage) consumer.poll();
			if (msg == null) {
				break;
			}
			
			KeyValue headers = msg.headers();
			String q = headers.getString(MessageHeader.QUEUE);
			String t = headers.getString(MessageHeader.TOPIC);
            String tOrq = q != null ? q : t;
            
			int seq = seqMap.getOrDefault(tOrq, zero);
			
			//verify message
			if (verifier.verify(msg, seq)) {
				msgCount.increment();
			} else {
				failCount.increment();
			}
			
			seqMap.put(tOrq, seq + 1);
		}
		
//		for (String k : seqMap.keySet()) {
//			System.out.println(" read " + seqMap.get(k) + " messages from " + k);
//		}
	};
}
