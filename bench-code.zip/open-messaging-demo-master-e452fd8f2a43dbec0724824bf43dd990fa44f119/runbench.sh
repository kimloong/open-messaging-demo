#!/bin/sh

export MAVEN_OPTS="-Xms2560m -Xmx2560m -XX:+PrintGCDateStamps -XX:+PrintGCDetails" 

rm stdout.log dstat.log -f
dstat -cmldt > dstat.log &

# producer
echo "Producer starts" > stdout.log
date +"%F %T" >> stdout.log
timeout 350 taskset -c 1,2,3,4 mvn exec:java -Dexec.mainClass="io.openmessaging.test.ProducerTest" | tee -a stdout.log

# flush os disk buffers
sync
echo 3 > /proc/sys/vm/drop_caches
sleep 5

# consumer
echo "Consumer starts" >> stdout.log
date +"%F %T" >> stdout.log
timeout 350 taskset -c 1,2,3,4 mvn exec:java -Dexec.mainClass="io.openmessaging.test.ConsumerTest" | tee -a stdout.log

sleep 5
killall dstat
