#!/bin/sh

if [ "$1" == "" ]; then
	echo "no param"
	exit
fi

now=`date +%Y%m%d`

for var in "$@"
do
	echo "$var"

	rm my-test-code/src/main/java/io/openmessaging/demo/*
	cp  $var/src/main/java/io/openmessaging/demo/* my-test-code/src/main/java/io/openmessaging/demo/
	rm -f temp/*

	cd my-test-code
	mvn compile
	./runbench.sh
	cd ..

	mkdir -p test-result/$now
	cp my-test-code/stdout.log test-result/$now/$var.stdout.log
	cp my-test-code/dstat.log test-result/$now/$var.dstat.log

  echo >> test-result/$now/results.log
	date +"%F %T" >> test-result/$now/results.log
  git -C $var rev-parse HEAD >> test-result/$now/results.log
	grep "count" -A 2 -H test-result/$now/$var.stdout.log >> test-result/$now/results.log
  du -h temp/ >> test-result/$now/results.log
  
  echo "********************" >> test-result/$now/results.log

done
