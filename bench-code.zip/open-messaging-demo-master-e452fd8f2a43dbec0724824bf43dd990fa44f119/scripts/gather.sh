#!/bin/sh

 ls test-result/`date +%Y%m%d`/*.stdout.log | xargs grep "count" -A 2

