#!/bin/sh

if [ "$1" == "" ]; then
	echo "no param"
	exit
fi
rm my-test-code/src/main/java/io/openmessaging/demo/*
cp  $1/src/main/java/io/openmessaging/demo/* my-test-code/src/main/java/io/openmessaging/demo/
rm -f temp/*
