链接：

[评测结果仓库，数据、图表等](http://git.sdp.nd/open-messaging/test-result)

[team1 冠裕组](http://git.sdp.nd/290536/open-messaging-demo)

[team2 廷彪组](http://git.sdp.nd/open-message-game/message_game)

[team3 金龙组](http://git.sdp.nd/150429/open-messaging-demo)

[评测代码](http://git.sdp.nd/332937/open-messaging-demo)

[对照组代码](http://git.sdp.nd/332937/open-messaging-demo/branches) lz 分支

[大杀器代码](http://git.sdp.nd/332937/open-messaging-demo/branches) lz3 分支

[幻灯片](http://git.sdp.nd/332937/open-messaging-demo/tree/master/public)
